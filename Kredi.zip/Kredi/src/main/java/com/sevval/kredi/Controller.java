package com.sevval.kredi;



import javax.websocket.server.PathParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

@RestController
public class Controller {

   /* public static final String ACCOUNT_SID =System.getenv("TWILIO_ACCOUNT_SID");
    public static final String AUTH_TOKEN =System.getenv("TWILIO_AUTH_TOKEN");
    */
    @RequestMapping(method = RequestMethod.GET, path = "/demo")
    public String krediSkoru(@PathParam("tc") int tc, @PathParam("name") String name, @PathParam("aylik_gelir") int aylik_gelir, @PathParam("phone") int phone/*,@RequestParam(value = "kredi_skor", defaultValue = getKredi_Skor) int kredi_skor*/) {
        int kredi_limit_carpani = 4;
        int kredi_limit;
        //Twilio.init(ACCOUNT_SID,AUTH_TOKEN);
        KrediSkoru a = new KrediSkoru();
        a.setKredi_skor((int) (aylik_gelir*0.1));
    
        if(a.getKredi_skor() < 500)
        {
       // Message message = Message.creator(new PhoneNumber(System.getenv("MY_PHONE_NUMBER")),new PhoneNumber("phone"),"Kredi skorunuz reddedilmiştir.").create();
            return "Kredi skorunuz reddedilmiştir.";
        }
        else if(a.getKredi_skor() >= 500 && aylik_gelir < 5000)
        {
            kredi_limit = 10000;
          //  Message message = Message.creator(new PhoneNumber(System.getenv("MY_PHONE_NUMBER")),new PhoneNumber("phone"),new KrediSkoru(name, aylik_gelir,a.getKredi_skor()).toString() + ". Kredi başvurunuz onaylanmıştır.Limitiniz " + kredi_limit + " TL dir.").create();
            return new KrediSkoru(name, aylik_gelir,a.getKredi_skor()).toString() + ". Kredi başvurunuz onaylanmıştır.Limitiniz " + kredi_limit + " TL dir."; 
        }
        else if(a.getKredi_skor() >= 1000){
            kredi_limit = aylik_gelir*kredi_limit_carpani;
           // Message message = Message.creator(new PhoneNumber(System.getenv("MY_PHONE_NUMBER")),new PhoneNumber("phone"),new KrediSkoru(name, aylik_gelir,a.getKredi_skor()).toString() + ". Kredi başvurunuz onaylanmıştır.Limitiniz " + kredi_limit + " TL dir.").create();
            return new KrediSkoru(name, aylik_gelir,a.getKredi_skor()).toString() + ". Kredi başvurunuz onaylanmıştır.Limitiniz " + kredi_limit + " TL dir.";
        }
        else{
            return "Yanlış veri girdiniz.";
        }
    }
   
}
