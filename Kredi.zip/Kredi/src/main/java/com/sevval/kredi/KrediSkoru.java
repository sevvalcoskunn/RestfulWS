package com.sevval.kredi;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("twilio")
public class KrediSkoru {
    
    private int tc;         
    private String name;
    private int aylik_gelir;
    private int phone;
    private int kredi_skor;        

    public KrediSkoru(String name, int aylik_gelir,int kredi_skor) {
        this.aylik_gelir = aylik_gelir;
        this.name = name;
        this.tc = tc;
        this.phone = phone;
        this.kredi_skor = kredi_skor;
    }
    public KrediSkoru(){
      
    }

    @Override
    public String toString() {
        return "Sayın "  + name + ", aylik geliriniz " + aylik_gelir + ". Kredi skorunuz : " + kredi_skor;
    }

    public int getKredi_skor() {
        return kredi_skor;
    }

    public void setKredi_skor(int kredi_skor) {
        this.kredi_skor = kredi_skor;
    }

    public int getTc() {
        return tc;
    }

    public void setTc(int tc) {
        this.tc = tc;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAylik_gelir() {
        return aylik_gelir;
    }

    public void setAylik_gelir(int aylik_gelir) {
        this.aylik_gelir = aylik_gelir;
    }

}
